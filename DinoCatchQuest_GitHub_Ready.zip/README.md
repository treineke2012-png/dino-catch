# Dino Catch Quest

Dino Catch Quest – GitHub Pages version.

## GitHub Pages
Upload the contents of this folder to the root of a GitHub repository and enable GitHub Pages from the `main` branch and `/ (root)`.
